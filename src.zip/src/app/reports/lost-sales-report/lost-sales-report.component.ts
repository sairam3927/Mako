import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lost-sales-report',
  templateUrl: './lost-sales-report.component.html',
  styleUrls: ['./lost-sales-report.component.scss']
})
export class LostSalesReportComponent implements OnInit {

  constructor() { }

  imagePath = '../../../../assets/img/vendor/leaflet/page_under_construction.png';

  ngOnInit() {
  }

}
