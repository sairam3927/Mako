import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outgoing-referral',
  templateUrl: './outgoing-referral.component.html',
  styleUrls: ['./outgoing-referral.component.scss']
})
export class OutgoingReferralComponent implements OnInit {

  constructor() { }

  imagePath = '../../../../assets/img/vendor/leaflet/page_under_construction.png';

  ngOnInit() {
  }

}
