import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-tests',
  templateUrl: './patient-tests.component.html',
  styleUrls: ['./patient-tests.component.scss']
})
export class PatientTestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
