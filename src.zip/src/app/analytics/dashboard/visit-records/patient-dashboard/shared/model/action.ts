export enum Action {
  CHANGE_THEME_COLOR,
  UNDEFINED
}
