//For Lost sales by reason   (auditeepie)
export const single = [
    {
      name: 'Houston',
      value: 1
    },
    {
      name: 'Dallas',
      value: 3
    },
    {
      name : 'Sugar Land',
      value:5
    },
    // {
    //   name : '15+ days',
    //   value:7
    // }
  ];
