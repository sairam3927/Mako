import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ann-notes-dialog',
  templateUrl: './ann-notes-dialog.component.html',
  styleUrls: ['./ann-notes-dialog.component.scss']
})
export class AnnNotesDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
