import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-clinical-notes',
  templateUrl: './patient-clinical-notes.component.html',
  styleUrls: ['./patient-clinical-notes.component.scss']
})
export class PatientClinicalNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
