import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visit-clinical-notes',
  templateUrl: './visit-clinical-notes.component.html',
  styleUrls: ['./visit-clinical-notes.component.scss']
})
export class VisitClinicalNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
