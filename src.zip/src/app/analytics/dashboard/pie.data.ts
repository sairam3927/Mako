export const single = [
    {
      name: 'Absent',
      value: 2300
    },
    {
      name: 'Heterozygous',
      value: 600
    },
    {
      name : 'Homozygous',
      value:850
    },
    {
      name : 'NoCall',
      value:245
    },
    // {
    //   name : 'Region',
    //   value:7
    // }
  ];
  export const Single = [
    {
      name: 'Absent',
      value: 60
    },
    {
      name: 'Heterozygous',
      value: 15
    },
    {
      name : 'Homozygous',
      value:12
    },
    { 
      name : 'NoCall',
      value:13
    },
  ];
  
    
      
       
          
          
