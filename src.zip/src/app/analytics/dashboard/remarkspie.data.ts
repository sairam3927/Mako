//for ageing analysis
export const single = [
    {
      name: 'Less than 10 days',
      value: 5
    },
    {
      name: '10-30 days',
      value: 8
    },
    {
      name : '30-60 days',
      value:10
    },
    {
      name : '60+ days',
      value:2
    }
  ];
