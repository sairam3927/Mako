import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-visits',
  templateUrl: './manage-visits.component.html',
  styleUrls: ['./manage-visits.component.scss']
})
export class ManageVisitsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
