import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-claim-dialog-in-manage-visits',
  templateUrl: './add-claim-dialog-in-manage-visits.component.html',
  styleUrls: ['./add-claim-dialog-in-manage-visits.component.scss']
})
export class AddClaimDialogInManageVisitsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
