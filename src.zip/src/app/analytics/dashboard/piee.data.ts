export const GenotypeSingle = [
  {
    name: 'A/A',
    value: 60
  },
  {
    name: 'A/T',
    value: 15
  },
  {
    name : 'A/C',
    value:12
  },
  { 
    name : 'A/G',
    value:13
  },
  {
    name: 'G/C',
    value: 60
  },
  {
    name: 'G/T',
    value: 15
  },
  {
    name : 'G/G',
    value:12
  },
  { 
    name : 'C/C',
    value:13
  },
  {
    name : 'C/T',
    value:12
  },
  { 
    name : 'T/T',
    value:13
  },
];

export const GenotypeTotal = [
  {
    name: 'A/A',
    value: 60
  },
  {
    name: 'A/T',
    value: 15
  },
  {
    name : 'A/C',
    value:12
  },
  { 
    name : 'A/G',
    value:13
  },
  {
    name: 'G/C',
    value: 60
  },
  {
    name: 'G/T',
    value: 15
  },
  {
    name : 'G/G',
    value:12
  },
  { 
    name : 'C/C',
    value:13
  },
  {
    name : 'C/T',
    value:12
  },
  { 
    name : 'T/T',
    value:13
  },
];

  
    
     
        
        