import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-questionnaire',
  templateUrl: './add-questionnaire.component.html',
  styleUrls: ['./add-questionnaire.component.scss']
})
export class AddQuestionnaireComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
