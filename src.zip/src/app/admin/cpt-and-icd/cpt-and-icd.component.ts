import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpt-and-icd',
  templateUrl: './cpt-and-icd.component.html',
  styleUrls: ['./cpt-and-icd.component.scss']
})
export class CptAndIcdComponent implements OnInit {

  constructor() { }
  
  imagePath = '../../../../assets/img/vendor/leaflet/page_under_construction.png';

  ngOnInit() {
  }

}
