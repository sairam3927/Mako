export const environment = {
  production: true,
  apiUrl : 'http://qa.makodnaapi.optionmatrix.org/',
};
